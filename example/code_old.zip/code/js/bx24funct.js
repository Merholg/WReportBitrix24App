/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
'use strict';
//            let age = prompt("Сколько Вам лет?", 18);
//            document.body.innerHTML = 'Новый BODY!';

document.body.strTableDescr =
{
    headT:   `<table border=\"1\" width=\"100%\" cellpadding=\"2\"> 
                <tr>
                    <th>ID</th>
                    <th>Наименование</th>
		    <th>Комментарий</th>
		    <th>Дата</th>
		    <th>Исполнитель</th>
                </tr>`,
//		    <th>END_DATE_PLAN</th>
//		    <th>RESPONSIBLE_ID</th>
    footT:  '</table>',
    cellT:  '',
    Num:    0,
    dateoption:
    {
//	era: 'long',
	year: 'numeric',
	month: 'long',
	day: 'numeric',
//	weekday: 'long',
//	timezone: 'UTC',
//	hour: 'numeric',
//	minute: 'numeric',
//	second: 'numeric'
    }
};

document.getElementById('ELECTROid').onclick = ElectroRep;
document.getElementById('HVACid').onclick = HVACRep;
//BX24.init(BX24init);
//            BX24.init(function()
//            {
//
//                BX24.callMethod('user.current', {}, function(res)
//                {
//                    var name = document.getElementById('name');
//                    name.innerHTML = res.data().NAME + ' ' + res.data().LAST_NAME;
//                    console.log(res.data());
//                });
//
//                console.log('B24 SDK is ready!', BX24.isAdmin());
//
//            });
BX24.init(function()
{
    BX24.callMethod('user.current', {}, function(res)
    {
        let cstatusvar = document.getElementById('cstatus');
        cstatusvar.textContent = 'B24 SDK is ready! '+ res.data().NAME + ' ' + res.data().LAST_NAME + (BX24.isAdmin() ? ' as Admin' : ' as User');
    });
});

function ElectroRep()
{
    document.body.strTableDescr.Num = 0;
    let cheadvar = document.getElementById('cheader');
    cheadvar.innerHTML = '<p>Журнал выполненных работ по ЭЛЕКТРИКЕ</p>';
    let cerrvar = document.getElementById('cerr');
    cerrvar.innerHTML = '<p>ELECTRO Ready</p>';
    document.body.strTableDescr.cellT = '';
    let creportvar = document.getElementById('creport');
    creportvar.innerHTML = '';
//    BX24.callMethod('tasks.task.list', 
//	{
//	filter:{REAL_STATUS: STATE_COMPLETED}, 
//	select: ['ID','TITLE','GROUP_ID'], 
//	order:{ID:'asc'}
//	}, 
    BX24.callMethod('task.item.list', 
    [
        {CLOSED_DATE : 'asc'},		// Сортировка по ID — по убыванию.
        {GROUP_ID: 15, STATUS: 5, ALLOW_TIME_TRACKING: 'N'}
//	,	// Фильтр
//        {	
//            NAV_PARAMS: { // постраничка
//                nPageSize : 2,	// по 2 элемента на странице.
//                iNumPage  : 2	// страница номер 2        
//            }
//        },
//	{SELECT: [ID, TITLE, GROUP_ID]}
    ],
    function(res)
	{
	    var cerrvar = document.getElementById('cerr');
	    if(res.error())
	    {
		cerrvar.innerHTML = '<p>ELECTRO Task Error</p>';
	    }
	    else
	    {
		cerrvar.innerHTML = '<p>ELECTRO Task Ready</p>';
		var rdata = res.data();
		rdata.forEach(function(item, index, array)
		{
		    var cldate = new Date(item.CLOSED_DATE);
		    document.body.strTableDescr.cellT += '<tr>' +
                                                 '<td>' + item.ID + '</td>' + 
                                                 '<td>' + item.TITLE + '</td>' +
						 '<td>' + item.DESCRIPTION + '</td>' +
						 '<td>' + cldate.toLocaleString("ru", document.body.strTableDescr.dateoption) + '</td>' +
						 '<td>' +  '' + '</td>' +
//                                                 '<td>' + item.END_DATE_PLAN + '</td>' + 
//                                                 '<td>' + item.RESPONSIBLE_ID + '</td>' +
							'</tr>';
		    ++(document.body.strTableDescr.Num);
		});
		if(res.more())
		{
		    res.next();
		}
		else
		{
		    document.body.strTableDescr.cellT += '<tr>' +
                                                 '<td><b>' + document.body.strTableDescr.Num + '</b></td>' + 
                                                 '<td>' + '' + '</td>' +
						 '<td>' + '' + '</td>' +
                                                 '<td>' + '' + '</td>' +
						 '<td>' + '' + '</td>' +
							'</tr>';
		    let creportvar = document.getElementById('creport');
		    creportvar.innerHTML = document.body.strTableDescr.headT + document.body.strTableDescr.cellT + document.body.strTableDescr.footT;
		}
	    }
	});
}

function HVACRep()
{
    document.body.strTableDescr.Num = 0;
    let cheadvar = document.getElementById('cheader');
    cheadvar.innerHTML = '<p>Журнал выполненных работ по ВЕНТИЛЯЦИИ и КОНДИЦИОНИРОВАНИЮ</p>';
    let cerrvar = document.getElementById('cerr');
    cerrvar.innerHTML = '<p>HVAC Ready</p>';
    document.body.strTableDescr.cellT = '';
    let creportvar = document.getElementById('creport');
    creportvar.innerHTML = '';
//    BX24.callMethod('tasks.task.list', 
//	{
//	filter:{REAL_STATUS: STATE_COMPLETED}, 
//	select: ['ID','TITLE','GROUP_ID'], 
//	order:{ID:'asc'}
//	}, 
    BX24.callMethod('task.item.list', 
    [
        {CLOSED_DATE : 'asc'},		// Сортировка по ID — по убыванию.
        {GROUP_ID: 9, STATUS: 5, ALLOW_TIME_TRACKING: 'N'}
//	,	// Фильтр
//        {	
//            NAV_PARAMS: { // постраничка
//                nPageSize : 2,	// по 2 элемента на странице.
//                iNumPage  : 2	// страница номер 2        
//            }
//        },
//	{SELECT: [ID, TITLE, GROUP_ID]}
    ],
    function(res)
	{
	    var cdate = new Date();
	    var cerrvar = document.getElementById('cerr');
	    if(res.error())
	    {
		cerrvar.innerHTML = '<p>HVAC Task Error</p>';
	    }
	    else
	    {
		cerrvar.innerHTML = '<p>HVAC Task Ready</p>';
		var rdata = res.data();
		rdata.forEach(function(item, index, array)
		{
		    var cldate = new Date(item.CLOSED_DATE);
		    if(item.END_DATE_PLAN.length > 0)
		    {
			var epdate = new Date(item.END_DATE_PLAN);
			if(epdate <= cdate)
			{
			    document.body.strTableDescr.cellT += '<tr>' +
                                                 '<td>' + item.ID + '</td>' + 
                                                 '<td>' + item.TITLE + '</td>' +
						 '<td>' + item.DESCRIPTION + '</td>' +
						 '<td>' + epdate.toLocaleString("ru", document.body.strTableDescr.dateoption) + '</td>' +
						 '<td>' + '' + '</td>' +
//						 '<td>' + item.UF_CRM_TASK[0] + '</td>' +
//						 '<td>' + item.CLOSED_DATE.substr(0,10) + '</td>' +
//                                                 '<td>' + item.END_DATE_PLAN + '</td>' + 
//                                                 '<td>' + item.RESPONSIBLE_ID + '</td>' +
								'</tr>';
			    ++(document.body.strTableDescr.Num);
			}
		    }
		    else
		    {
			document.body.strTableDescr.cellT += '<tr>' +
                                                 '<td>' + item.ID + '</td>' + 
                                                 '<td>' + item.TITLE + '</td>' +
						 '<td>' + item.DESCRIPTION + '</td>' +
						 '<td>' + cldate.toLocaleString("ru", document.body.strTableDescr.dateoption) + '</td>' +
						 '<td>' + '' + '</td>' +
//						 '<td>' + item.UF_CRM_TASK[0] + '</td>' +
//                                                 '<td>' + item.END_DATE_PLAN + '</td>' + 
//                                                 '<td>' + item.RESPONSIBLE_ID + '</td>' +
							    '</tr>';
		    }
		});
		if(res.more())
		{
		    res.next();
		}
		else
		{
		    document.body.strTableDescr.cellT += '<tr>' +
                                                 '<td><b>' + document.body.strTableDescr.Num + '</b></td>' + 
                                                 '<td>' + '' + '</td>' +
						 '<td>' + '' + '</td>' +
                                                 '<td>' + '' + '</td>' +
						 '<td>' + '' + '</td>' +
							'</tr>';
		    let creportvar = document.getElementById('creport');
		    creportvar.innerHTML = document.body.strTableDescr.headT + document.body.strTableDescr.cellT + document.body.strTableDescr.footT;
		}
	    }
	});
}

//function getCurrentUser() 
//{
//    const currentUserPromise = new Promise((resolve, reject) => 
//    {
//        BX24.init(function()
//        {
//            BX24.callMethod("user.current", {}, function(res) 
//            {
//                document.body.strTableDescr.cellT += '<tr>' +
//                                                    '<td>' + res.data().NAME + '</td>' + 
//                                                    '<td>' + res.data().LAST_NAME + '</td>' +
//                                                '</tr>';
//            });
//        });
//    });
//    return currentUserPromise;
//}

